declare module 'alertifyjs';
